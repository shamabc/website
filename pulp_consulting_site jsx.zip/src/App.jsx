import React, { useState } from "react";
import { Menu, X } from "lucide-react";

export default function ConsultingWebsite() {
  const [menuOpen, setMenuOpen] = useState(false);

  const services = [
    { title: "Algorithms Consulting", desc: "We help design and optimize algorithms tailored to your business needs." },
    { title: "Data Consulting", desc: "Unlock the power of data with analytics, insights, and strategic consulting." },
    { title: "Computing Power Network", desc: "Providing scalable computing solutions and network optimization." },
    { title: "Training & Consulting Centre", desc: "Professional training and development programs for growth." },
  ];

  return (
    <div className="font-sans">
      <header className="fixed w-full bg-white shadow-md z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center p-4">
          <h1 className="text-2xl font-bold text-blue-700">Pulp Consulting</h1>
          <nav className="hidden md:flex gap-6 text-gray-700">
            <a href='#home' className="hover:text-blue-600">Home</a>
            <a href='#about' className="hover:text-blue-600">About Us</a>
            <a href='#services' className="hover:text-blue-600">Services</a>
            <a href='#training' className="hover:text-blue-600">Training</a>
            <a href='#gallery' className="hover:text-blue-600">Gallery</a>
            <a href='#contact' className="hover:text-blue-600">Contact</a>
          </nav>
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden">
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
        {menuOpen && (
          <div className="bg-white shadow-md flex flex-col gap-4 p-4 md:hidden">
            <a href='#home'>Home</a>
            <a href='#about'>About Us</a>
            <a href='#services'>Services</a>
            <a href='#training'>Training</a>
            <a href='#gallery'>Gallery</a>
            <a href='#contact'>Contact</a>
          </div>
        )}
      </header>

      <section id='home' className="h-screen flex flex-col justify-center items-center bg-gradient-to-r from-blue-600 to-blue-400 text-white text-center px-4">
        <h2 className="text-4xl md:text-6xl font-bold mb-6">Without continual growth and progress...</h2>
        <p className="mb-6 text-lg md:text-2xl max-w-2xl">“…such words as improvement, achievement, and success have no meaning.” – Benjamin Franklin</p>
        <button className="bg-white text-blue-600 font-bold px-6 py-3 rounded-xl shadow">Explore Our Services</button>
      </section>

      <section id='about' className="py-20 bg-gray-50 px-6 md:px-20">
        <h3 className="text-3xl font-bold text-center mb-8">About Us</h3>
        <p className="max-w-4xl mx-auto text-center text-gray-700 mb-6">
          Established in 2019, Pulp Consulting specializes in Consulting, Supply, and Trading. We strive to deliver excellence, quality, and value to both private and government sectors.
        </p>
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <div className="p-6 bg-white rounded-xl shadow">
            <h4 className="text-xl font-semibold mb-2">Our Mission</h4>
            <p>To enhance excellence in quality, delivery, and equitable pricing with full dedication and loyalty.</p>
          </div>
          <div className="p-6 bg-white rounded-xl shadow">
            <h4 className="text-xl font-semibold mb-2">Our Vision</h4>
            <p>Within 5 years, to be among the top consulting companies, leveraging skilled manpower and cutting-edge technologies.</p>
          </div>
        </div>
      </section>

      <section id='services' className="py-20 px-6 md:px-20">
        <h3 className="text-3xl font-bold text-center mb-12">Our Services</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {services.map((s, i) => (
            <div key={i} className="p-6 bg-white rounded-xl shadow">
              <h4 className="text-lg font-semibold mb-2">{s.title}</h4>
              <p className="text-gray-600 text-sm">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section id='training' className="py-20 bg-gray-50 px-6 md:px-20 text-center">
        <h3 className="text-3xl font-bold mb-6">Training & Consulting Centre</h3>
        <p className="max-w-3xl mx-auto text-gray-700 mb-6">We offer training programs and workshops designed to empower professionals with the latest industry skills.</p>
        <button className="bg-blue-600 text-white font-bold px-6 py-3 rounded-xl shadow">Enroll Now</button>
      </section>

      <section id='gallery' className="py-20 px-6 md:px-20">
        <h3 className="text-3xl font-bold text-center mb-12">Gallery</h3>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <div className="bg-gray-200 h-48 rounded-xl"></div>
          <div className="bg-gray-200 h-48 rounded-xl"></div>
          <div className="bg-gray-200 h-48 rounded-xl"></div>
        </div>
      </section>

      <section id='contact' className="py-20 bg-blue-600 text-white px-6 md:px-20">
        <h3 className="text-3xl font-bold text-center mb-8">Contact Us</h3>
        <div className="max-w-3xl mx-auto text-center">
          <p className="mb-4">Cyber 12, 63000, Cyberjaya, Kuala Lumpur</p>
          <p className="mb-4">Phone: 012-353-9553 | Email: shamsul@pulpconsulting.com</p>
          <button className="bg-white text-blue-600 font-bold px-6 py-3 rounded-xl shadow">Send a Message</button>
        </div>
      </section>

      <footer className="bg-gray-900 text-gray-400 text-center py-6">
        <p>© {new Date().getFullYear()} Pulp Consulting. All rights reserved.</p>
      </footer>
    </div>
  );
}